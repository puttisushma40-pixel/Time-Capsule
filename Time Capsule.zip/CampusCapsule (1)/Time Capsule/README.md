# Time Capsule
A browser-only digital time-capsule app (HTML5, CSS3, vanilla JS).

## Run
Unzip, then open `index.html` in a modern browser (Chrome, Edge, Firefox, Safari). No install, no server. Microphone recording works best when served from `http://localhost` (e.g. `python3 -m http.server` in this folder); file uploads work either way.

## Features
Demo welcome flow; dashboard with all 11 capsule types, stats, recent and upcoming; create/view/edit/delete with validation; drafts; search and filter; Locked / Ready / Opened / Drafts views; photo, audio (record + upload), video uploads; live letter preview; group entries with names and timestamps; gift-box opening animation with Close and Replay; hanging Polaroid Photo Wall with full-size view; reduced-motion support; responsive layout.

## Storage
Capsule records are in localStorage; photos, audio and video blobs are in IndexedDB (no Base64). Deleting a capsule removes its media. Data stays in this browser and does not sync between devices. Clearing site data erases it.

## Honest limits
- The "welcome" login is a demo; there is no authentication, cloud storage or encryption.
- Group Capsule is a local demo, not real collaboration.
- Locking is enforced only by browser code (one function, `canOpen`). Anyone controlling the browser, its stored data or the system clock can bypass it. Editing a locked capsule also shows its fields to its owner.
- Secret Surprise is a reveal effect, not secure confidentiality.
- Music links are stored as text; no music is downloaded.

## Update: accounts, personal photo walls, sharing
- **Accounts (demo):** Create account / Sign in with email-or-username and password (show/hide, validation, Log out). Accounts and capsules live only in this browser; each account has its own capsules and photo walls. Passwords are salted and hashed (PBKDF2) in the browser, but this is NOT real authentication. Capsules saved before accounts existed are adopted by the first account created. Hashing needs a secure context: use `http://localhost` (`python3 -m http.server`) if a `file://` open fails.
- **My Photo Walls:** nav "My Walls" or "Create My Photo Wall". Many walls per account; name, theme, add/remove/reorder photos, caption, date, location and sticker per photo. Photos are in IndexedDB. Not synced across devices.
- **Share Capsule:** "Share" on any saved capsule creates an invitation file (`.capsule.json`) containing only that capsule, your name, a personal message and the opening date you choose. Nothing is emailed or uploaded. Your friend uses "Import a shared capsule" and gets a sealed gift with the normal opening animation. File contents are readable and the date lock is enforced only by the app.
- **Group Capsule:** list members, add memories (text and files) with names and timestamps while locked (contents hidden until opening). Friends collaborate by swapping files: share the group out, friends add memories and share it back, and importing it merges new contributions. This is manual and not real-time.

## Premium upgrade (v3)
- **Demo Login:** "Continue with a demo profile" (name editable in Settings), or create your own local profile. "Log out / switch profile" in the header. Demo only, not secure authentication.
- **My Photo Walls:** creation form (name, description, theme, decorative style, optional cover), gallery cards with Open / Edit / Delete (with confirmation), Add Your First Photo empty state, themes and styles (fairy lights, washi tape, starry), reorder, captions, dates, locations, stickers.
- **Shared** page: pick a capsule, choose a gift cover, create an invitation with a polished preview, Copy message, WhatsApp share link, and download the invitation file. Lists "Shared with me" and "Invitations I created". Status is always "created locally"; nothing is emailed or sent.
- **Group Memories** page: create groups with members, add contributions as any member name, contributor/timestamp list, delete controls, countdown, cover, and the shared timeline revealed with the gift animation.
- Local data lives in this browser, is not backed up or synced, and is erased if you clear browser data. Date locks are not tamper-proof.
